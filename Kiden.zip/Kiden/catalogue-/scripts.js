<script>
        // Mobile menu toggle
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const mobileMenu = document.getElementById('mobile-menu');
            mobileMenu.classList.toggle('hidden');
        });

        // Function to set up image gallery for a given property
        function setupImageGallery(propertyId) {
            const mainImage = document.getElementById(`main-image-${propertyId}`);
            const photoUploadInput = document.getElementById(`photo-upload-${propertyId}`);
            const thumbnailContainer = document.getElementById(`thumbnail-container-${propertyId}`);

            photoUploadInput.addEventListener('change', function(event) {
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const newThumbnail = document.createElement('img');
                        newThumbnail.src = e.target.result;
                        newThumbnail.alt = 'Uploaded View';
                        newThumbnail.classList.add('thumbnail-image', 'cursor-pointer', 'rounded-lg', 'hover:opacity-75', 'transition-opacity');
                        newThumbnail.addEventListener('click', function() {
                            mainImage.src = this.src;
                            mainImage.alt = this.alt;
                        });

                        // Insert the new thumbnail before the photo upload div
                        const uploadDiv = thumbnailContainer.querySelector('div:last-child');
                        if (uploadDiv) {
                            thumbnailContainer.insertBefore(newThumbnail, uploadDiv);
                        } else {
                            thumbnailContainer.appendChild(newThumbnail);
                        }

                        mainImage.src = e.target.result;
                        mainImage.alt = 'Uploaded Main View';
                    };
                    reader.readAsDataURL(file);
                }
            });

            // If there are any initial thumbnails, set up their click listeners
            const initialThumbnails = thumbnailContainer.querySelectorAll('.thumbnail-image');
            initialThumbnails.forEach(thumbnail => {
                thumbnail.addEventListener('click', function() {
                    mainImage.src = this.src;
                    mainImage.alt = this.alt.replace('Thumbnail', 'Main view');
                });
            });
        }

        // Setup image galleries for each property
        setupImageGallery('kanyaryeru');
        setupImageGallery('karungi');
        setupImageGallery('ruti');
        setupImageGallery('masha');
        setupImageGallery('kakoma-kabagarame');
        setupImageGallery('kyarwabuganda-junction');
        setupImageGallery('nyarubanga');
        setupImageGallery('ishanyu');
        setupImageGallery('nyakisharara');
        setupImageGallery('kakoma');
        setupImageGallery('rwobuyanje');
        setupImageGallery('kakoba-bsu');
        setupImageGallery('katamba');
        setupImageGallery('kyarwabuganda');
        setupImageGallery('rwenturagara');
        setupImageGallery('rwenjeru');
        setupImageGallery('butagasi');
        setupImageGallery('nsikye');

    </script>