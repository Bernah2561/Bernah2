<?php
// Set the title for this specific page
$pageTitle = 'Property Catalogue';

// Include the header template
include 'includes/header.php';

// Include the property data array
require_once 'data/properties-data.php';
?>

<?php foreach ($properties as $property): ?>
<main class="container mx-auto px-6 py-12">
    <div class="bg-white p-8 rounded-2xl shadow-2xl">
        <div class="grid grid-cols-1 lg:grid-cols-5 gap-12">
            
            <div class="lg:col-span-3">
                <div class="mb-4">
                    <img id="main-image-<?php echo $property['id']; ?>" src="<?php echo htmlspecialchars($property['main_image']); ?>" alt="Main view of <?php echo htmlspecialchars($property['name']); ?>" class="w-full h-auto object-cover rounded-xl shadow-lg">
                </div>
                <div class="grid grid-cols-4 gap-4 thumbnail-container" data-main-image-id="main-image-<?php echo $property['id']; ?>">
                    <img src="<?php echo htmlspecialchars($property['main_image']); ?>" alt="Thumbnail for <?php echo htmlspecialchars($property['name']); ?>" class="thumbnail-img cursor-pointer w-full h-24 object-cover rounded-lg border-2 border-yellow-500">
                    
                    <?php foreach ($property['thumbnails'] as $thumb): ?>
                        <img src="<?php echo htmlspecialchars($thumb); ?>" alt="Thumbnail for <?php echo htmlspecialchars($property['name']); ?>" class="thumbnail-img cursor-pointer w-full h-24 object-cover rounded-lg hover:border-2 hover:border-yellow-500">
                    <?php endforeach; ?>
                    
                    <div>
                        <div class="w-full h-24 bg-gray-200 rounded-lg flex flex-col items-center justify-center text-gray-500 p-2">
                            <i class="fas fa-camera fa-lg mb-1"></i>
                            <span class="text-xs text-center">More Photos</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="lg:col-span-2">
                <h1 class="text-4xl font-extrabold text-gray-800 mb-2"><?php echo htmlspecialchars($property['name']); ?></h1>
                <p class="text-lg text-gray-500 mb-6">Your Prime Plot in Mbarara City</p>

                <div class="mb-6">
                    <span class="text-5xl font-bold text-yellow-600"><?php echo htmlspecialchars($property['price']); ?></span>
                    <span class="text-gray-500"> UGX</span>
                </div>

                <div class="mb-8 border-t border-b border-gray-200 py-6">
                    <h3 class="text-xl font-bold text-gray-800 mb-4">Key Features</h3>
                    <ul class="space-y-4">
                        <li class="flex items-center text-lg"><i class="fas fa-ruler-combined text-yellow-500 w-6 mr-3"></i><span><span class="font-bold">Size:</span> <?php echo htmlspecialchars($property['size']); ?></span></li>
                        <li class="flex items-center text-lg"><i class="fas fa-file-contract text-yellow-500 w-6 mr-3"></i><span><span class="font-bold">Title:</span> <?php echo htmlspecialchars($property['title_status']); ?></span></li>
                        <li class="flex items-center text-lg"><i class="fas fa-road text-yellow-500 w-6 mr-3"></i><span><span class="font-bold">Distance:</span> <?php echo htmlspecialchars($property['distance']); ?></span></li>
                        <li class="flex items-center text-lg"><i class="fas fa-map-marker-alt text-yellow-500 w-6 mr-3"></i><span><span class="font-bold">Location:</span> <?php echo htmlspecialchars($property['location']); ?></span></li>
                    </ul>
                </div>

                <div class="mb-8">
                    <h3 class="text-xl font-bold text-gray-800 mb-3">Description</h3>
                    <p class="text-gray-600 leading-relaxed"><?php echo htmlspecialchars($property['description']); ?></p>
                </div>

                <a href="https://wa.me/256778215243?text=<?php echo urlencode($property['whatsapp_inquiry']); ?>" target="_blank" rel="noopener noreferrer">
                    <button class="w-full bg-gray-800 text-white font-bold py-4 px-8 rounded-full text-lg hover:bg-black cta-button flex items-center justify-center shadow-lg transition-all duration-300 transform hover:scale-105">
                        <i class="fab fa-whatsapp mr-3"></i>
                        Inquire on WhatsApp
                    </button>
                </a>
            </div>
        </div>
    </div>
</main>
<?php endforeach; ?>

<?php
// Include the footer template
include 'includes/footer.php';