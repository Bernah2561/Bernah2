<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Sanitize and retrieve form data
    $name = filter_var(trim($_POST["name"]), FILTER_SANITIZE_STRING);
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $message = filter_var(trim($_POST["message"]), FILTER_SANITIZE_STRING);

    // 2. Validate data
    if (empty($name) || empty($message) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Redirect back to contact page with an error
        header("Location: contact.php?status=error");
        exit;
    }

    // 3. Set up email parameters
    $to = "kidenrealestate@gmail.com"; // Your receiving email address
    $subject = "New Contact Form Submission from $name";
    $email_content = "Name: $name\n";
    $email_content .= "Email: $email\n\n";
    $email_content .= "Message:\n$message\n";
    $headers = "From: $name <$email>";

    // 4. Send the email
    if (mail($to, $subject, $email_content, $headers)) {
        // Redirect back to contact page with a success message
        header("Location: contact.php?status=success");
    } else {
        // Redirect back to contact page with a failure message
        header("Location: contact.php?status=fail");
    }
} else {
    // If not a POST request, redirect to the home page
    header("Location: index.php");
}
?>