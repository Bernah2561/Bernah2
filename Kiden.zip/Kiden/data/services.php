<?php
$services = [
    [
        'icon' => 'fa-map-marked-alt',
        'title' => 'Land Sales',
        'description' => 'We offer a wide selection of prime plots and acreage for residential and commercial development.'
    ],
    [
        'icon' => 'fa-home',
        'title' => 'Property Management',
        'description' => 'Professional management services to protect your investment and maximize your returns.'
    ],
    [
        'icon' => 'fa-hard-hat',
        'title' => 'Construction',
        'description' => 'High-quality construction services, from custom homes to commercial buildings, delivered on time and on budget.'
    ]
];
?>