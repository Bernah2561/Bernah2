<?php

$properties = [
    [
        'id' => 'kanyaryeru',
        'name' => 'Kanyaryeru Estate',
        'price' => '@7.5M',
        'main_image' => 'assets/kanyaryeru-main.jpg', // Replace with your image path
        'thumbnails' => [
            'assets/kanyaryeru-thumb1.jpg',
            'assets/kanyaryeru-thumb2.jpg',
            'assets/kanyaryeru-thumb3.jpg',
        ],
        'size' => '50*100 ft',
        'title_status' => 'Yes (Titled)',
        'distance' => '1km from Tarmac',
        'location' => 'Mbarara City',
        'description' => "Discover the perfect opportunity to build your dream home or invest in a rapidly growing area. This titled 50x100ft plot in Kanyaryeru Estate offers an ideal blend of tranquility and accessibility. Located just 1km from the main road, you'll enjoy both peace and convenience. Don't miss out on this prime piece of real estate in Mbarara City.",
        'whatsapp_inquiry' => "Hi, I am interested in the Kanyaryeru Estate plot for sale."
    ],
    [
        'id' => 'karungi',
        'name' => 'Karungi Estate',
        'price' => '@10M',
        'main_image' => 'assets/karungi-main.jpg', // Replace with your image path
        'thumbnails' => [], // Add thumbnail paths here if you have them
        'size' => '50*100 ft',
        'title_status' => 'Yes (Titled)',
        'distance' => '1km from Tarmac',
        'location' => 'Mbarara City',
        'description' => "Discover the perfect opportunity to build your dream home or invest in a rapidly growing area. This titled 50x100ft plot in Karungi Estate offers an ideal blend of tranquility and accessibility with electricity and water supply. Located just 1km from the main road, you'll enjoy both peace and convenience. Don't miss out on this prime piece of real estate in Mbarara City.",
        'whatsapp_inquiry' => "Hi, I am interested in the Karungi Estate plot for sale."
    ],
    [
        'id' => 'ruti',
        'name' => 'Ruti Estate',
        'price' => '@19M',
        'main_image' => 'assets/ruti-main.jpg', // Replace with your image path
        'thumbnails' => [],
        'size' => '50*100 ft',
        'title_status' => 'Yes (Titled)',
        'distance' => '1.3km from Tarmac',
        'location' => 'Mbarara City',
        'description' => "Discover the perfect opportunity to build your dream home or invest in a rapidly growing area. This titled 50x100ft plot in Ruti Estate offers an ideal blend of tranquility and accessibility with electricity and water supply. Located just 1.3km from the main road, you'll enjoy both peace and convenience. Don't miss out on this prime piece of real estate in Mbarara City.",
        'whatsapp_inquiry' => "Hi, I am interested in the Ruti Estate plot for sale."
    ],
    [
        'id' => 'masha-mile-1',
        'name' => 'Masha Mile 1 Estate',
        'price' => '@14M',
        'main_image' => 'assets/masha-main.jpg', // Replace with your image path
        'thumbnails' => [],
        'size' => '50*100 ft',
        'title_status' => 'Yes (Titled)',
        'distance' => '1.5km from Tarmac',
        'location' => 'Mbarara City',
        'description' => "Discover the perfect opportunity to build your dream home or invest in a rapidly growing area. This titled 50x100ft plot in Masha Mile 1 Estate offers an ideal blend of tranquility and accessibility with electricity and water supply. Located just 1.5km from the main road, you'll enjoy both peace and convenience. Don't miss out on this prime piece of real estate in Mbarara City.",
        'whatsapp_inquiry' => "Hi, I am interested in the Masha Mile 1 Estate plot for sale."
    ],
    [
        'id' => 'kakoma-kabagarame',
        'name' => 'Kakoma Kabagarame Estate',
        'price' => '@7M',
        'main_image' => 'assets/kakoma-main.jpg', // Replace with your image path
        'thumbnails' => [],
        'size' => '50*100 ft',
        'title_status' => 'No (Not Titled)',
        'distance' => '5km from Main',
        'location' => 'Mbarara City',
        'description' => "Discover the perfect opportunity to build your dream home or invest in a rapidly growing area. This 50x100ft plot in Kakoma Kabagarame Estate offers an ideal blend of tranquility and accessibility with electricity and water supply. Located just 5km from the main road, you'll enjoy both peace and convenience. Don't miss out on this prime piece of real estate in Mbarara City.",
        'whatsapp_inquiry' => "Hi, I am interested in the Kakoma Kabagarame Estate plot for sale."
    ],
    [
        'id' => 'kyarwabuganda-junction',
        'name' => 'Kyarwabuganda Junction Estate',
        'price' => '@23M',
        'main_image' => 'assets/kyarwabuganda-main.jpg', // Replace with your image path
        'thumbnails' => [],
        'size' => '50*100 ft',
        'title_status' => 'Yes (Titled)',
        'distance' => '1.5km from Tarmac',
        'location' => 'Mbarara City',
        'description' => "Discover the perfect opportunity to build your dream home or invest in a rapidly growing area. This titled 50x100ft plot in Kyarwabuganda Junction Estate offers an ideal blend of tranquility and accessibility with electricity and water supply. Located just 1.5km from the main road, you'll enjoy both peace and convenience. Don't miss out on this prime piece of real estate in Mbarara City.",
        'whatsapp_inquiry' => "Hi, I am interested in the Kyarwabuganda Junction Estate plot for sale."
    ],
    // You can continue adding more properties here...
];