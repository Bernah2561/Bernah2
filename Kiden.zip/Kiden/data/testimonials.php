<?php
$testimonials = [
    [
        'quote' => "Kiden made our dream of owning a home a reality. Their professionalism and dedication are unmatched. We couldn't be happier with our new house!",
        'name' => 'John & Jane Doe',
        'title' => 'Happy Homeowners',
        'image_text' => 'J'
    ],
    [
        'quote' => 'The construction team at Kiden is top-notch. They delivered a high-quality commercial building for us ahead of schedule. Highly recommended!',
        'name' => 'A. K. Musisi',
        'title' => 'Business Owner',
        'image_text' => 'A'
    ]
];
?>