<?php
$properties = [
    [
        'name' => 'Luxury Villa in Muyenga',
        'image' => 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?q=80&w=2070&auto=format&fit=crop',
        'details' => '4 Beds | 5 Baths | 2 Garages',
        'price' => '$450,000'
    ],
    [
        'name' => 'Modern Apartment in Kololo',
        'image' => 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=2070&auto=format&fit=crop',
        'details' => '2 Beds | 2 Baths | City View',
        'price' => '$200,000'
    ],
    [
        'name' => 'Cozy Suburban Home',
        'image' => 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?q=80&w=2070&auto=format&fit=crop',
        'details' => '3 Beds | 2 Baths | Garden',
        'price' => '$300,000'
    ]
];
?>