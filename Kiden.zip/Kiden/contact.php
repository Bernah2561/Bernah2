<?php
// PHP code to process the form submission

// Variable to store a status message for the user
$statusMsg = '';

// Check if the form has been submitted using the 'POST' method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // --- Collect and Sanitize Form Data ---
    // Use trim() to remove any extra whitespace from the beginning or end
    // Use htmlspecialchars() to prevent XSS attacks by converting special characters to HTML entities
    $name = trim(htmlspecialchars($_POST['name']));
    $email = trim(htmlspecialchars($_POST['email']));
    $message = trim(htmlspecialchars($_POST['message']));

    // --- Validation ---
    if (empty($name) || empty($email) || empty($message)) {
        // Check if any fields are empty
        $statusMsg = '<div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">Please fill out all fields.</div>';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Check for a valid email format
        $statusMsg = '<div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">Please enter a valid email address.</div>';
    } else {
        // --- If Validation Passes, Send Email ---

        // Recipient Email Address (WHERE THE EMAIL WILL BE SENT)
        $to = "kidenrealestateco@gmail.com";

        // Email Subject
        $subject = "New Message from Contact Form: " . $name;

        // Email Body (The content of the email)
        // Using nl2br() to preserve line breaks from the textarea
        $email_content = "Name: " . $name . "\n";
        $email_content .= "Email: " . $email . "\n\n";
        $email_content .= "Message:\n" . $message . "\n";

        // Email Headers
        // This tells email clients who the email is from
        $headers = "From: " . $name . " <" . $email . ">";

        // --- Send the Email using PHP's mail() function ---
        if (mail($to, $subject, $email_content, $headers)) {
            $statusMsg = '<div class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg" role="alert">Thank you for your message! It has been sent successfully.</div>';
        } else {
            $statusMsg = '<div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">Oops! Something went wrong and we couldn\'t send your message.</div>';
        }
    }
}
?>
