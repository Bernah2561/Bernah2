document.addEventListener('DOMContentLoaded', function() {

    const mainImage = document.getElementById('main-image');
    const photoUpload = document.getElementById('photo-upload');
    const thumbnailContainer = document.getElementById('thumbnail-container');

    // --- Image Gallery Logic ---
    function setupGallery() {
        const thumbnails = document.querySelectorAll('.thumbnail-image');
        
        thumbnails.forEach(thumb => {
            thumb.addEventListener('click', function() {
                // Remove active class from all thumbnails
                thumbnails.forEach(t => t.classList.remove('active'));
                
                // Add active class to the clicked thumbnail
                this.classList.add('active');
                
                // Change the main image source
                mainImage.src = this.src.replace('200x150', '800x500'); // Get higher res image
                
                // Add a fade-in animation
                mainImage.classList.remove('image-fade-in');
                void mainImage.offsetWidth; // Trigger reflow
                mainImage.classList.add('image-fade-in');
            });
        });
        
        // Set the first thumbnail as active by default
        if(thumbnails.length > 0) {
            thumbnails[0].classList.add('active');
        }
    }

    // --- Photo Upload Logic ---
    photoUpload.addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                // Create a new thumbnail for the uploaded image
                const newThumb = document.createElement('img');
                newThumb.src = e.target.result;
                newThumb.alt = 'Uploaded Photo';
                newThumb.classList.add('thumbnail-image', 'cursor-pointer', 'rounded-lg', 'hover:opacity-75', 'transition-opacity');
                
                // Insert the new thumbnail before the upload button
                thumbnailContainer.insertBefore(newThumb, thumbnailContainer.lastElementChild);
                
                // Re-initialize the gallery to include the new thumbnail
                setupGallery();
                
                // Automatically click the new thumbnail to display it as the main image
                newThumb.click();
            };
            
            reader.readAsDataURL(file);
        }
    });

    // Initial setup of the gallery
    setupGallery();

});
