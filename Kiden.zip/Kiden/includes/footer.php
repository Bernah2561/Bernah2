<footer id="contact" class="bg-gray-800 text-white py-16">
        <div class="container mx-auto px-6">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-12">
                <div>
                    <h3 class="text-xl font-bold mb-4">KIDEN REAL ESTATE & CONSTRUCTION CO. LTD.</h3>
                    <p class="text-gray-400 mb-4">The Real Estate Company You Must Trust. We are dedicated to providing the best service in the industry.</p>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-400 hover:text-white"><i class="fab fa-facebook-f fa-lg"></i></a>
                        <a href="#" class="text-gray-400 hover:text-white"><i class="fab fa-twitter fa-lg"></i></a>
                        <a href="#" class="text-gray-400 hover:text-white"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#" class="text-gray-400 hover:text-white"><i class="fab fa-linkedin-in fa-lg"></i></a>
                    </div>
                </div>

                <div>
                    <h3 class="text-xl font-bold mb-4">Get In Touch</h3>
                    <ul class="space-y-3 text-gray-400">
                        <li class="flex items-start">
                            <i class="fas fa-map-marker-alt mt-1 mr-3 text-yellow-500"></i>
                            <span>Amazon Building, Level 3, Room 07B, Mbarara</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-phone-alt mr-3 text-yellow-500"></i>
                            <span>+256 778 215 243 / +256 740 791 479</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-envelope mr-3 text-yellow-500"></i>
                            <span>kidenrealestate@gmail.com</span>
                        </li>
                    </ul>
                </div>

                <div>
                    <h3 class="text-xl font-bold mb-4">Send Us a Message</h3>
                    <form action="process_contact.php" method="POST">
                        <div class="mb-4">
                            <input type="text" name="name" placeholder="Your Name" class="w-full px-4 py-2 bg-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500" required>
                        </div>
                        <div class="mb-4">
                            <input type="email" name="email" placeholder="Your Email" class="w-full px-4 py-2 bg-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500" required>
                        </div>
                        <div class="mb-4">
                            <textarea name="message" placeholder="Your Message" rows="4" class="w-full px-4 py-2 bg-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-yellow-500" required></textarea>
                        </div>
                        <button type="submit" class="w-full bg-yellow-600 text-white font-bold py-2 px-4 rounded-full hover:bg-yellow-700 cta-button">Send Message</button>
                    </form>
                </div>
            </div>
            <div class="mt-12 border-t border-gray-700 pt-6 text-center text-gray-500">
                <p>&copy; <?php echo date("Y"); ?> Kiden Real Estate & Construction Co. Ltd. All Rights Reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>