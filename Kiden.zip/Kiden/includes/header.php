<?php
// Get the current page name to set the active class on the nav link
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?> | Kiden Real Estate & Construction Co. Ltd.</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="icon" href="assets/favicon.ico" type="image/x-icon">
    <script src="script.js" defer></script>
    <style>
        /* A simple class for the active nav link */
        .active-link {
            color: #D97706; /* This is tailwind's yellow-600 */
            font-weight: 600;
        }
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://images.unsplash.com/photo-1582407947304-fd86f028f716?q=80&w=2070&auto=format&fit=crop') no-repeat center center/cover;
        }
    </style>
</head>
<body class="bg-gray-50 text-gray-800 font-['Inter']">

    <header class="bg-white shadow-md sticky top-0 z-50">
        <nav class="container mx-auto px-6 py-4 flex justify-between items-center">
            <a href="index.php" class="flex items-center space-x-2">
                <img src="assets/KidenLogo1-01.png" alt="Kiden Logo" class="h-12 w-12">
                <span class="ml-2 text-xl font-semibold text-gray-800">Kiden Real Estate</span>
            </a>
            <div class="hidden md:flex items-center space-x-8">
                <a href="index.php" class="<?php echo ($currentPage == 'index.php') ? 'active-link' : 'text-gray-600'; ?> hover:text-yellow-600">Home</a>
                <a href="about.php" class="<?php echo ($currentPage == 'about.php') ? 'active-link' : 'text-gray-600'; ?> hover:text-yellow-600">About</a>
                <a href="services.php" class="<?php echo ($currentPage == 'services.php') ? 'active-link' : 'text-gray-600'; ?> hover:text-yellow-600">Services</a>
                <a href="properties.php" class="<?php echo ($currentPage == 'properties.php') ? 'active-link' : 'text-gray-600'; ?> hover:text-yellow-600">Properties</a>
                <a href="contact.php" class="bg-yellow-600 text-white px-4 py-2 rounded-full hover:bg-yellow-700 cta-button">Contact Us</a>
            </div>
            <button id="mobile-menu-button" class="md:hidden text-gray-800">
                <i class="fas fa-bars fa-2x"></i>
            </button>
        </nav>
        <div id="mobile-menu" class="hidden md:hidden px-6 pb-4">
            <a href="index.php" class="block py-2 text-gray-600 hover:text-yellow-600">Home</a>
            <a href="about.php" class="block py-2 text-gray-600 hover:text-yellow-600">About</a>
            <a href="services.php" class="block py-2 text-gray-600 hover:text-yellow-600">Services</a>
            <a href="properties.php" class="block py-2 text-gray-600 hover:text-yellow-600">Properties</a>
            <a href="contact.php" class="block mt-2 bg-yellow-600 text-white px-4 py-2 rounded-full text-center hover:bg-yellow-700 cta-button">Contact Us</a>
        </div>
    </header>