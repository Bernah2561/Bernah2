<?php
$pageTitle = 'Properties';
include 'includes/header.php';
require_once 'data/properties.php';
?>

<main class="py-20 bg-white">
    <div class="container mx-auto px-6">
        <h2 class="text-3xl font-bold text-center mb-12">Our Properties</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php foreach ($properties as $property): // Loop through all properties ?>
            <div class="bg-white rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-2 transition-transform duration-300">
                <img src="<?php echo htmlspecialchars($property['image']); ?>" alt="<?php echo htmlspecialchars($property['name']); ?>" class="w-full h-56 object-cover">
                <div class="p-6">
                    <h3 class="text-xl font-bold mb-2"><?php echo htmlspecialchars($property['name']); ?></h3>
                    <p class="text-gray-600 mb-4"><?php echo htmlspecialchars($property['details']); ?></p>
                    <div class="flex justify-between items-center">
                        <span class="text-2xl font-bold text-yellow-600"><?php echo htmlspecialchars($property['price']); ?></span>
                        <a href="#" class="bg-gray-800 text-white px-4 py-2 rounded-full hover:bg-gray-900">Details</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>