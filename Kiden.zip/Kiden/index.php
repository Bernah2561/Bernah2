<?php
// Set the page title for this page
$pageTitle = 'Home';

// Include the header
include 'includes/header.php';

// Include data files
require_once 'data/properties.php';
require_once 'data/services.php';
require_once 'data/testimonials.php';
?>

<section id="home" class="hero-section h-screen flex items-center justify-center text-white text-center">
    <div class="container mx-auto px-6">
        <h1 class="text-4xl md:text-6xl font-extrabold leading-tight mb-4 animate-fade-in-down">Your Gateway to Exceptional Living in Mbarara City</h1>
        <p class="text-lg md:text-xl mb-8 max-w-3xl mx-auto animate-fade-in-up">Buy | Sell | Grow with us. <br>The Real Estate Company You Must Trust.</p>
        <a href="properties.php" class="bg-yellow-600 text-white font-bold py-3 px-8 rounded-full text-lg hover:bg-yellow-700 cta-button animate-bounce">Explore Properties</a>
    </div>
</section>

<section id="about-preview" class="py-20 bg-white">
    <div class="container mx-auto px-6 text-center">
        <h2 class="text-3xl font-bold mb-2">About Kiden</h2>
        <p class="text-gray-600 mb-12 max-w-3xl mx-auto">We are a premier real estate and construction company dedicated to helping you find your dream property and building it to perfection.</p>
        <a href="about.php" class="bg-gray-800 text-white font-bold py-3 px-6 rounded-full hover:bg-gray-900 cta-button">Learn More About Us</a>
    </div>
</section>

<section id="services" class="py-20">
    <div class="container mx-auto px-6">
        <h2 class="text-3xl font-bold text-center mb-12">Our Services</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            <?php foreach ($services as $service): ?>
            <div class="bg-white p-8 rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300">
                <div class="text-yellow-600 mb-4"><i class="fas <?php echo $service['icon']; ?> fa-3x"></i></div>
                <h3 class="text-xl font-bold mb-2"><?php echo htmlspecialchars($service['title']); ?></h3>
                <p class="text-gray-600"><?php echo htmlspecialchars($service['description']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section id="properties" class="py-20 bg-white">
    <div class="container mx-auto px-6">
        <h2 class="text-3xl font-bold text-center mb-12">Featured Properties</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php foreach (array_slice($properties, 0, 3) as $property): // Show only first 3 ?>
            <div class="bg-white rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-2 transition-transform duration-300">
                <img src="<?php echo htmlspecialchars($property['image']); ?>" alt="<?php echo htmlspecialchars($property['name']); ?>" class="w-full h-56 object-cover">
                <div class="p-6">
                    <h3 class="text-xl font-bold mb-2"><?php echo htmlspecialchars($property['name']); ?></h3>
                    <p class="text-gray-600 mb-4"><?php echo htmlspecialchars($property['details']); ?></p>
                    <div class="flex justify-between items-center">
                        <span class="text-2xl font-bold text-yellow-600"><?php echo htmlspecialchars($property['price']); ?></span>
                        <a href="#" class="bg-gray-800 text-white px-4 py-2 rounded-full hover:bg-gray-900">Details</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="py-20">
    <div class="container mx-auto px-6">
        <h2 class="text-3xl font-bold text-center mb-12">What Our Clients Say</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <?php foreach ($testimonials as $testimonial): ?>
            <div class="bg-white p-8 rounded-lg shadow-lg">
                <p class="text-gray-600 italic mb-4">"<?php echo htmlspecialchars($testimonial['quote']); ?>"</p>
                <div class="flex items-center">
                    <img src="https://placehold.co/50x50/E2E8F0/4A5568?text=<?php echo htmlspecialchars($testimonial['image_text']); ?>" alt="Client" class="w-12 h-12 rounded-full mr-4">
                    <div>
                        <p class="font-bold"><?php echo htmlspecialchars($testimonial['name']); ?></p>
                        <p class="text-sm text-gray-500"><?php echo htmlspecialchars($testimonial['title']); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php
// Include the footer
include 'includes/footer.php';
?>